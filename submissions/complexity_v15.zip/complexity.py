from collections import Iterable

import numpy as np
import tensorflow as tf

try:
    import cPickle as pickle
except ImportError:
    import pickle

from tensorflow.keras.layers import Layer


def convert_model(model: tf.keras.Model, shape, lambda_0):
    inp = tf.keras.layers.Input(shape)
    x = inp
    for lyr in model.layers:
        x = NoiseLayer(np.exp(-lambda_0))(x)
        x = lyr(x)
        lambda_0 += 1
    model_t = tf.keras.Model(inp, x)
    return model_t


class NoiseLayer(Layer):
    def __init__(self, stdev,
                 **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(NoiseLayer, self).__init__(**kwargs)
        self.noise_layer = tf.keras.layers.GaussianNoise(stdev, )

    def call(self, inputs, **kwargs):
        base = tf.ones_like(inputs)
        noise = self.noise_layer(base, True)
        return inputs * noise


def estimate_accuracy(model: tf.keras.Model,
                      dataset,
                      iteration: int,
                      should_encode: (int, bool)):
    acc = 0.0
    for _ in range(iteration):
        x, y = dataset.next()
        if should_encode:
            y = tf.one_hot(y, should_encode)
        acc += model.evaluate(x, y, verbose=0)[1]
    return acc / iteration


def train_model(model: tf.keras.Model,
                dataset,
                iteration: int,
                should_encode: (int, bool)):
    for _ in range(iteration):
        x, y = dataset.next()
        if should_encode:
            y = tf.one_hot(y, should_encode)
        model.train_on_batch(x, y)
    return model


# def complexity(model: tf.keras.Model, dataset: tf.data.Dataset):
#     batched_ds = iter(dataset.shuffle(1000).repeat(-1).batch(64))
#     test_ds = iter(dataset.shuffle(1000).repeat(-1).batch(1))
#     should_encode = False
#     x, y = test_ds.next()
#     yp = model.predict(x)
#     w_orig = model.get_weights()
#     if list(yp.shape) != y.shape.as_list():
#         should_encode = yp.shape[-1]
#     cce = tf.keras.losses.CategoricalCrossentropy()
#     optimizer = tf.keras.optimizers.Adam(learning_rate=1e-3)
#     lo = -5.0
#     hi = 10.0
#     mid = 0
#     model.compile(optimizer, cce, metrics=["accuracy"])
#     orig_acc = estimate_accuracy(model, batched_ds, 10, should_encode) - 0.1
#     m = 0.5
#     n = 0.5
#     for _ in range(20):
#         p = m * hi + n * lo
#         mid = 0.5 * (hi + lo)
#         model_n = convert_model(model, batched_ds.next()[0].shape[1:], p)
#         model_n.compile(optimizer, cce, metrics=["accuracy"])
#         acc = estimate_accuracy(model_n, batched_ds, 10, should_encode)
#         if abs(acc - orig_acc) < 0.0025:
#             break
#         elif acc - orig_acc > 0.0025:
#             hi = mid
#         else:
#             lo = mid
#     model_n = train_model(model_n, batched_ds, 20, should_encode)
#     w = model_n.get_weights()
#     norm = sum([np.linalg.norm(w - w_i) ** 2 for (w, w_i) in zip(w, w_orig)])
#     return norm

@tf.function()
def get_jacobian(inputs, model):
    """Get jacobians with respect to intermediate layers."""
    with tf.GradientTape(persistent=True) as tape:
        out = model(inputs)
    dct = {}
    for i, l in enumerate(model.layers):
        try:
            g = tape.batch_jacobian(out, l._last_seen_input)
            if g != None:
                dct[i] = g
        except AttributeError:  # no _last_seen_input, layer not wrapped (ex: flatten)
            continue
    return dct


def complexity(model: tf.keras.Model, dataset: tf.data.Dataset):
    batched_ds = iter(dataset.shuffle(1000).repeat(-1).batch(64))
    test_ds = iter(dataset.shuffle(1000).repeat(-1).batch(1))
    x, y = test_ds.next()
    yp = model.predict(x)
    x_ref, y_ref = batched_ds.next()
    grads_orig = get_jacobian(x_ref, model)
    model_n = convert_model(model, x_ref.shape.as_list()[1:], 1.25)
    grads = get_jacobian(x_ref, model_n)
    norm = np.mean([np.mean(np.square(v - v0)) ** 0.5 for v, v0 in zip(grads.values(), grads_orig.values())])
    return norm
