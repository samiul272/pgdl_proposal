import numpy as np
import tensorflow as tf

try:
    import cPickle as pickle
except ImportError:
    import pickle


def find_target_layer(model):
    for layer in reversed(model.layers):
        if len(layer.output_shape) == 5:
            return layer.name
    raise ValueError("Could not find 4D layer. Cannot apply GradCAM")


def convert_model(model, shape):
    co = []
    inp = tf.keras.layers.Input(shape)
    x = inp
    for lyr in model.layers:
        x = tf.keras.layers.TimeDistributed(lyr)(x)
        if lyr.trainable:
            co.append(x)
    model_t = tf.keras.Model(inp, [co, x])
    return model_t


def calculate_moments(grad, nn_out):
    axes = tuple(range(len(grad.shape)))[1:-1]
    norm_grads = tf.divide(grad, tf.reduce_mean(tf.square(grad), axis=-1, keepdims=True))
    weights = tf.reduce_mean(norm_grads, axis=axes, keepdims=True)
    cam = tf.reduce_sum(tf.multiply(weights, nn_out), axis=-1, keepdims=True)
    cam = tf.maximum(cam, 0)
    cam = cam / tf.reduce_max(cam, axes, keepdims=True)
    cam = tf.where(tf.math.is_nan(cam), tf.zeros_like(cam), cam)
    m = tf.nn.moments(cam, axes=None)
    return m


def stack_ragged(tensors):
    values = tf.concat(tensors, axis=0)
    lens = tf.stack([tf.shape(t, out_type=tf.int64)[0] for t in tensors])
    return tf.RaggedTensor.from_row_lengths(values, lens)


def calculate_complexity(model_t, x, y, eps):
    with tf.GradientTape() as tape:
        inputs = tf.cast(x, tf.float32)
        nn_outs, preds = model_t(inputs)  # preds after softmax
        loss = preds * y
    grads = tape.gradient(loss, nn_outs)
    elems = list(zip(grads, nn_outs))
    m = list(map(lambda args: calculate_moments(*args), elems))
    m = tf.stack(m)
    base = tf.exp(tf.range(0, -len(elems), -1, dtype=tf.float32))
    base = tf.expand_dims(base, -1)
    l = m.shape[0]
    return tf.reduce_mean(1 + m, 0) / l


def calculate_complexity_v2(model_t, x, y, eps):
    with tf.GradientTape() as tape:
        inputs = tf.cast(x, tf.float32)
        nn_outs, preds = model_t(inputs)  # preds after softmax
        loss = preds * y
    grads = tape.gradient(loss, nn_outs)
    elems = list(zip(grads, nn_outs))
    m = list(map(lambda args: calculate_moments(*args), elems))
    m = tf.stack(m)
    return m


def assert_model_output(model: tf.keras.Model, dataset: tf.data.Dataset) -> bool:
    for x, y in dataset.batch(1):
        yp = model(x)
        if yp.shape != y.shape and yp.shape[:-1] == y.shape:
            return yp.shape[-1]
        return False


def complexity_bak(model, dataset):
    model_t = None
    eps = 1e-5
    should_expand_target = assert_model_output(model, dataset)
    i = 0
    params = {'mu_p': 0, 'var_p': 0, 'mu_all': 0, 'var_all': 0}
    for x, y in dataset.batch(512):
        if should_expand_target:
            y = tf.one_hot(y, should_expand_target)
        shape = x.shape
        if model_t is None:
            model_t = convert_model(model, shape)
        x = tf.expand_dims(x, 0)
        m = calculate_complexity(model_t, x, y, eps)
        mu_p, var_p = m[0], m[1]
        m = calculate_complexity(model_t, x, tf.ones_like(y) - y, eps)
        mu_all, var_all = m[0], m[1]
        params['mu_p'] += mu_p
        params['var_p'] += var_p
        params['mu_all'] += mu_all
        params['var_all'] += var_all
        i += 1
        if i == 1:
            break
    return {k: params[k] / i for k in params.keys()}


def complexity(model, dataset):
    model_t = None
    eps = 1e-5
    should_expand_target = assert_model_output(model, dataset)
    i = 0
    limit = 32
    c = 0
    # params = {'mu_p': 0, 'var_p': 0, 'mu_all': 0, 'var_all': 0, 'computed': 0}
    for x, y in dataset.batch(16):
        if should_expand_target:
            y = tf.one_hot(y, should_expand_target)
        shape = x.shape
        if model_t is None:
            model_t = convert_model(model, shape)
        x = tf.expand_dims(x, 0)
        m = calculate_complexity_v2(model_t, x, y, eps)
        m_c = calculate_complexity_v2(model_t, x, tf.ones_like(y) - y, eps)
        # var0 = tf.nn.moments(x, axes=None)[1]

        mu = m[:, 0]
        var = m[:, 1]
        mu_c = m_c[:, 0]
        var_c = m_c[:, 1]
        # params['mu_p'] += tf.reduce_mean(mu)
        # params['var_p'] += tf.reduce_mean(var)
        # params['mu_all'] += tf.reduce_mean(mu_c)
        # params['var_all'] += tf.reduce_mean(var_c)

        c += tf.math.log(tf.reduce_sum((mu / (eps + var) - mu_c / (eps + var_c)) ** 2) ** 0.5)
        # params['computed'] += c
        i += 1
        if i == limit:
            break

    return -(c.numpy()/limit)
